import express from 'express';
import cors from 'cors';
import sqlite3 from 'sqlite3';

const app = express();
app.use(cors());
app.use(express.json());

const db = new sqlite3.Database('./database.db');

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT,
    sobrenome TEXT,
    telefone TEXT,
    endereco TEXT,
    cpf TEXT,
    placa TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS servicos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER,
    servico TEXT,
    preco REAL,
    data TEXT,
    entrada TEXT,
    saida TEXT
  )`);
});

app.get('/clientes', (req, res) => {
  db.all("SELECT * FROM clientes", [], (err, rows) => {
    res.json(rows);
  });
});

app.post('/clientes', (req, res) => {
  const { nome, sobrenome, telefone, endereco, cpf, placa } = req.body;
  db.run(
    `INSERT INTO clientes (nome, sobrenome, telefone, endereco, cpf, placa)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [nome, sobrenome, telefone, endereco, cpf, placa],
    function () {
      res.json({ id: this.lastID });
    }
  );
});

app.get('/servicos', (req, res) => {
  db.all("SELECT * FROM servicos", [], (err, rows) => {
    res.json(rows);
  });
});

app.post('/servicos', (req, res) => {
  const { cliente_id, servico, preco, data, entrada, saida } = req.body;
  db.run(
    `INSERT INTO servicos (cliente_id, servico, preco, data, entrada, saida)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [cliente_id, servico, preco, data, entrada, saida],
    function () {
      res.json({ id: this.lastID });
    }
  );
});

app.listen(3001, () => console.log('Backend rodando na porta 3001'));
